﻿namespace APP_Saude
{
    partial class questionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Resposta_Nome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(12, 372);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(468, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Qual é a tua idade?";
            // 
            // Resposta_Nome
            // 
            this.Resposta_Nome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.Resposta_Nome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Resposta_Nome.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.Resposta_Nome.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Resposta_Nome.Location = new System.Drawing.Point(19, 323);
            this.Resposta_Nome.MaxLength = 50;
            this.Resposta_Nome.Name = "Resposta_Nome";
            this.Resposta_Nome.Size = new System.Drawing.Size(462, 23);
            this.Resposta_Nome.TabIndex = 3;
            this.Resposta_Nome.Text = "Insira o seu nome..";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 20F);
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(38, -494);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(468, 55);
            this.label2.TabIndex = 4;
            this.label2.Text = "Quantos anos tens?";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(12, 475);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(468, 55);
            this.label4.TabIndex = 6;
            this.label4.Text = "Qual é a sua altura?";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Century Gothic", 20F);
            this.label6.ForeColor = System.Drawing.Color.Gainsboro;
            this.label6.Location = new System.Drawing.Point(61, -348);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(590, 55);
            this.label6.TabIndex = 8;
            this.label6.Text = "Quantos litros de água bebes por dia?";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Gainsboro;
            this.label7.Location = new System.Drawing.Point(9, 1323);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(468, 55);
            this.label7.TabIndex = 14;
            this.label7.Text = "Consome legumes?";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Gainsboro;
            this.label8.Location = new System.Drawing.Point(9, 1213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(468, 55);
            this.label8.TabIndex = 13;
            this.label8.Text = "Quantas frutas come durante o dia?";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Gainsboro;
            this.label9.Location = new System.Drawing.Point(12, 1101);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(468, 55);
            this.label9.TabIndex = 12;
            this.label9.Text = "Consome o pequeno-almoço?";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Gainsboro;
            this.label10.Location = new System.Drawing.Point(12, 989);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(599, 55);
            this.label10.TabIndex = 11;
            this.label10.Text = "Se for vegetariano, que tipo de proteína consome?";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(12, 590);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(619, 55);
            this.label11.TabIndex = 9;
            this.label11.Text = "Quanto pesas?";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Gainsboro;
            this.label14.Location = new System.Drawing.Point(9, 1422);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(599, 55);
            this.label14.TabIndex = 16;
            this.label14.Text = "Quantas vezes por semana você come fast food?";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(12, 272);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(468, 55);
            this.label3.TabIndex = 24;
            this.label3.Text = "Como te chamas?";
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Gainsboro;
            this.label16.Location = new System.Drawing.Point(12, 884);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(536, 55);
            this.label16.TabIndex = 21;
            this.label16.Text = "Tipo de carne mais consome nas refeições?";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Gainsboro;
            this.label17.Location = new System.Drawing.Point(12, 792);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(448, 55);
            this.label17.TabIndex = 20;
            this.label17.Text = "Quantos litros de agua bebe por dia?";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.Gainsboro;
            this.label18.Location = new System.Drawing.Point(12, 689);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(601, 55);
            this.label18.TabIndex = 19;
            this.label18.Text = "Quantas refeições tomas por dia?";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox1.ForeColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox1.Location = new System.Drawing.Point(17, 424);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(161, 21);
            this.comboBox1.TabIndex = 25;
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox2.ForeColor = System.Drawing.Color.White;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox2.Location = new System.Drawing.Point(19, 533);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(161, 21);
            this.comboBox2.TabIndex = 26;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox3.ForeColor = System.Drawing.Color.White;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox3.Location = new System.Drawing.Point(19, 643);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(161, 21);
            this.comboBox3.TabIndex = 27;
            // 
            // comboBox4
            // 
            this.comboBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox4.ForeColor = System.Drawing.Color.White;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox4.Location = new System.Drawing.Point(19, 747);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(161, 21);
            this.comboBox4.TabIndex = 28;
            // 
            // comboBox5
            // 
            this.comboBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox5.ForeColor = System.Drawing.Color.White;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox5.Location = new System.Drawing.Point(19, 843);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(161, 21);
            this.comboBox5.TabIndex = 29;
            // 
            // comboBox6
            // 
            this.comboBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox6.ForeColor = System.Drawing.Color.White;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox6.Location = new System.Drawing.Point(17, 942);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(161, 21);
            this.comboBox6.TabIndex = 30;
            // 
            // comboBox7
            // 
            this.comboBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox7.ForeColor = System.Drawing.Color.White;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox7.Location = new System.Drawing.Point(17, 1047);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(161, 21);
            this.comboBox7.TabIndex = 31;
            // 
            // comboBox8
            // 
            this.comboBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox8.ForeColor = System.Drawing.Color.White;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox8.Location = new System.Drawing.Point(17, 1159);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(161, 21);
            this.comboBox8.TabIndex = 32;
            // 
            // comboBox9
            // 
            this.comboBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox9.ForeColor = System.Drawing.Color.White;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox9.Location = new System.Drawing.Point(14, 1271);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(161, 21);
            this.comboBox9.TabIndex = 33;
            // 
            // comboBox10
            // 
            this.comboBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox10.ForeColor = System.Drawing.Color.White;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox10.Location = new System.Drawing.Point(17, 1374);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(161, 21);
            this.comboBox10.TabIndex = 34;
            // 
            // comboBox11
            // 
            this.comboBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.comboBox11.ForeColor = System.Drawing.Color.White;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "-18",
            "18 - 25",
            "25 - 34",
            "35 - 44",
            "45 - 54",
            "55 - 64",
            "65 - 74",
            "75 - 84",
            "85 - 94",
            "95+"});
            this.comboBox11.Location = new System.Drawing.Point(17, 1480);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(161, 21);
            this.comboBox11.TabIndex = 35;
            // 
            // questionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(63)))), ((int)(((byte)(69)))));
            this.ClientSize = new System.Drawing.Size(804, 447);
            this.Controls.Add(this.comboBox11);
            this.Controls.Add(this.comboBox10);
            this.Controls.Add(this.comboBox9);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.comboBox6);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Resposta_Nome);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "questionario";
            this.Text = "Questionario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Resposta_Nome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox11;
    }
}